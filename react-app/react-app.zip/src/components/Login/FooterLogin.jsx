

export default function FooterLogin() {
    return (
        <div className="footer-login-panel">
            <div id="title-footer">
                Developed By Youssef Mahdi | Boujrada Yassine | Bella Abdelouhab - ISIL : 2023 
            </div>
        </div>
    )
}