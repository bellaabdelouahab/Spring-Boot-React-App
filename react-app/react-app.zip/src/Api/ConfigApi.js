

const getApiPath=()=>{
    return "http://localhost:8081";
}

const config={getApiPath}

export default config;